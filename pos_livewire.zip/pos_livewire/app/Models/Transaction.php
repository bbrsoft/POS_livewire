<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    use HasFactory;

    /**
     * fillable
     */
    protected $fillable = ['invoice', 'user_id', 'grand_total', 'cash', 'change'];

    /**
     * relation user
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * relation details
     */
    public function details()
    {
        return $this->hasMany(TransactionDetail::class);
    }
}
